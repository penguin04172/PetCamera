-------- PROJECT GENERATOR --------
PROJECT NAME :	week16_sccb
PROJECT DIRECTORY :	C:\Users\USER\Desktop\week16_sccb\week16_sccb
CPU SERIES :	RX600
CPU TYPE :	RX62T
TOOLCHAIN NAME :	Renesas RX Standard Toolchain
TOOLCHAIN VERSION :	1.0.1.0
GENERATION FILES :
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\dbsct.c
        Setting of B,R Section
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\typedefine.h
        Aliases of Integer Type
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\sbrk.c
        Program of sbrk
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\iodefine.h
        Definition of I/O Register
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\intprg.c
        Interrupt Program
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\vecttbl.c
        Initialize of Vector Table
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\vect.h
        Definition of Vector
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\resetprg.c
        Reset Program
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\week16_sccb.c
        Main Program
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\sbrk.h
        Header file of sbrk file
    C:\Users\USER\Desktop\week16_sccb\week16_sccb\stacksct.h
        Setting of Stack area
START ADDRESS OF SECTION :
 H'1000	B_1,R_1,B_2,R_2,B,R,SU,SI
 H'FFFF8000	PResetPRG
 H'FFFF8100	C_1,C_2,C,C$*,D*,P,PIntPRG,W*
 H'FFFFFFD0	FIXEDVECT

* When the user program is executed,
* the interrupt mask has been masked.
* 
* Program start 0xFFFF8000.
* RAM start 0x1000.

SELECT TARGET :
    RX600 Segger J-Link
DATE & TIME : 2022/6/6 �U�� 03:46:54
