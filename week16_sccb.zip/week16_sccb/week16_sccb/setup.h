#include <stdint.h>

uint8_t rdReg(uint8_t reg);
void wrReg (uint8_t reg, uint8_t val);
void set_reg_Complex(void);
void delayMs(uint16_t time);