/******************************************************************************
* DISCLAIMER
* Please refer to http://www.renesas.com/disclaimer
******************************************************************************
* Copyright (C) 2010 Renesas Electronics Corporation.
* and Renesas Solutions Corporation. All rights reserved.
******************************************************************************
* File Name    : r_pdl_user_definitions.h
* Version      : 
* Description  : User-modifiable definitions
******************************************************************************
* History : 10.06.2022 Version Description
*         :   
******************************************************************************/



#ifndef R_PDL_USER_DEFS_H
#define R_PDL_USER_DEFS_H
#define FAST_INTC_VECTOR 0
#endif



