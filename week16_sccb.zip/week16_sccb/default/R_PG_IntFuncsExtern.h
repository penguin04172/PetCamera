/******************************************************************************
* DISCLAIMER
* Please refer to http://www.renesas.com/disclaimer
******************************************************************************
* Copyright (C) 2010 Renesas Electronics Corporation.
* and Renesas Solutions Corporation. All rights reserved.
******************************************************************************
* File Name    : R_PG_IntFuncsExtern.h
* Version      : 
* Description  : 
******************************************************************************
* History : 10.06.2022 Version Description
*         :   
******************************************************************************/



extern void s1Func(void);
extern void s3Func(void);
extern void s2Func(void);
extern void delayFunc(void);
extern void u2TxFunc(void);
extern void u2RxFunc(void);
extern void i2cRxFunc(void);
extern void i2cTxFunc(void);
extern void i2cSlFunc(void);



